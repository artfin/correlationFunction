#ifndef AR_HE_DIP_BURYAK_FIT_H
#define AR_HE_DIP_BURYAK_FIT_H

double ar_he_dip_buryak_fit( const double& R );

#endif
