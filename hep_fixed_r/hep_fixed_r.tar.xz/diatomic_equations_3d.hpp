#ifndef DIATOMIC_EQUATIONS_3D_HPP
#define DIATOMIC_EQUATIONS_3D_HPP

void rhs_3D(double* out, double R, double pR, double theta, double pTheta, double phi, double pPhi );

#endif // DIATOMIC_EQUATIONS_3D_HPP

