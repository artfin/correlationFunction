#ifndef DIATOMIC_EQUATIONS_2D_H
#define DIATOMIC_EQUATIONS_2D_H

void rhs_2D(double* out, double R, double pR, double psi, double ppsi );

#endif
