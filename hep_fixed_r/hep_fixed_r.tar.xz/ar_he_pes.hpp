#ifndef AR_HE_PES_H
#define AR_HE_PES_H

double ar_he_pot(double R);
#endif

