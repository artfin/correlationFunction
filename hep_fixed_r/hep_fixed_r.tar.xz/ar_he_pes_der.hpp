#ifndef AR_HE_PES_DER_H
#define AR_HE_PES_DER_H

double ar_he_pot_der(double R);

#endif

